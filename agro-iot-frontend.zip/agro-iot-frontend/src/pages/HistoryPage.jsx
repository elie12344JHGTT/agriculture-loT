import React, { useEffect, useMemo, useState } from "react";
import api from "../api/axios";
import { logAudit } from "../api/audit";

const tabs = ["Mesures", "Alertes", "Actions"];
const HISTORY_ROWS_PER_PAGE = 7;

function normalizeText(value) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

function tableBadgeClass(value) {
  const normalized = normalizeText(value);
  if (normalized.includes("crit") || normalized.includes("failed") || normalized.includes("echec") || normalized.includes("erreur")) return "danger";
  if (normalized.includes("moy") || normalized.includes("warning") || normalized.includes("attention") || normalized.includes("attente")) return "warning";
  if (normalized.includes("success") || normalized.includes("ok") || normalized.includes("actif") || normalized.includes("resolu")) return "ok";
  return "neutral";
}
// Export local des lignes selectionnees; peut etre remplace par GET /exports/history.
function exportRowsAsCsv(filename, headers, rows) {
  const escapeCsv = (value) => `"${String(value ?? "").replaceAll('"', '""')}"`;
  const content = [headers.join(","), ...rows.map((row) => headers.map((header) => escapeCsv(row[header])).join(","))].join("\n");
  const blob = new Blob([content], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function rowKey(row, index) {
  return row.id_mesure || row.id_alerte || row.id_action || `${row.date_mesure || row.date_creation || row.date_action}-${index}`;
}

function EmptyRow({ colSpan, label }) {
  return (
    <tr className="empty-table-row">
      <td colSpan={colSpan}>{label}</td>
    </tr>
  );
}

function Pagination({ label, total, page, pageCount, startIndex, endIndex, onPageChange }) {
  if (total <= HISTORY_ROWS_PER_PAGE) {
    return null;
  }

  return (
    <div className="users-pagination" aria-label={label}>
      <span>{startIndex}-{endIndex} sur {total}</span>
      <div>
        <button
          className="toolbar-button"
          type="button"
          onClick={() => onPageChange(Math.max(1, page - 1))}
          disabled={page === 1}
        >
          Precedent
        </button>
        <strong>Page {page} / {pageCount}</strong>
        <button
          className="toolbar-button"
          type="button"
          onClick={() => onPageChange(Math.min(pageCount, page + 1))}
          disabled={page === pageCount}
        >
          Suivant
        </button>
      </div>
    </div>
  );
}

// Calcule une pagination frontend de 7 lignes par page.
function getPageMeta(rows, page) {
  const pageCount = Math.max(1, Math.ceil(rows.length / HISTORY_ROWS_PER_PAGE));
  const safePage = Math.min(page, pageCount);
  const startIndex = rows.length === 0 ? 0 : (safePage - 1) * HISTORY_ROWS_PER_PAGE + 1;
  const endIndex = Math.min(safePage * HISTORY_ROWS_PER_PAGE, rows.length);
  const paginatedRows = rows.slice((safePage - 1) * HISTORY_ROWS_PER_PAGE, safePage * HISTORY_ROWS_PER_PAGE);

  return { safePage, pageCount, startIndex, endIndex, paginatedRows };
}

export function HistoryPage() {
  const [activeTab, setActiveTab] = useState("Mesures");
  const [filter, setFilter] = useState("Tous");
  const [dateFilter, setDateFilter] = useState("");
  const [measureHistoryRows, setMeasureHistoryRows] = useState([]);
  const [alertHistoryRows, setAlertHistoryRows] = useState([]);
  const [actionHistoryRows, setActionHistoryRows] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [measurePage, setMeasurePage] = useState(1);
  const [alertPage, setAlertPage] = useState(1);
  const [actionPage, setActionPage] = useState(1);
  const [selectedMeasures, setSelectedMeasures] = useState([]);
  const [selectedAlerts, setSelectedAlerts] = useState([]);
  const [selectedActions, setSelectedActions] = useState([]);

  useEffect(() => {
    let isMounted = true;

    async function loadHistory() {
      setIsLoading(true);
      setLoadError("");

      try {
        const params = { limit: 50 };
        if (activeTab === "Mesures" && dateFilter) {
          params.date = dateFilter;
        }

        const endpointByTab = {
          Mesures: "/api/history/measurements",
          Alertes: "/api/history/alerts",
          Actions: "/api/history/actions"
        };

        const response = await api.get(endpointByTab[activeTab], { params });

        if (!isMounted) {
          return;
        }

        const rows = response.data?.rows ?? [];

        if (activeTab === "Mesures") {
          setMeasureHistoryRows(rows);
          setMeasurePage(1);
          setSelectedMeasures([]);
        }

        if (activeTab === "Alertes") {
          setAlertHistoryRows(rows);
          setAlertPage(1);
          setSelectedAlerts([]);
        }

        if (activeTab === "Actions") {
          setActionHistoryRows(rows);
          setActionPage(1);
          setSelectedActions([]);
        }
      } catch (error) {
        if (isMounted) {
          setLoadError("Impossible de charger l'historique depuis Laravel");
        }
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    }

    loadHistory();

    return () => {
      isMounted = false;
    };
  }, [activeTab, dateFilter]);

  const filteredMeasures = useMemo(() => {
    if (filter === "Tous") {
      return measureHistoryRows;
    }

    const selectedType = normalizeText(filter);
    return measureHistoryRows.filter((row) => normalizeText(row.type_mesure).includes(selectedType));
  }, [filter, measureHistoryRows]);

  const measureRows = useMemo(
    () => filteredMeasures.map((row, index) => ({ ...row, key: rowKey(row, index) })),
    [filteredMeasures]
  );

  const alertRows = useMemo(
    () => alertHistoryRows.map((row, index) => ({ ...row, key: rowKey(row, index) })),
    [alertHistoryRows]
  );

  const actionRows = useMemo(
    () => actionHistoryRows.map((row, index) => ({ ...row, key: rowKey(row, index) })),
    [actionHistoryRows]
  );

  const measureMeta = getPageMeta(measureRows, measurePage);
  const alertMeta = getPageMeta(alertRows, alertPage);
  const actionMeta = getPageMeta(actionRows, actionPage);

  const selectedMeasureRows = measureRows.filter((row) => selectedMeasures.includes(row.key));
  const selectedAlertRows = alertRows.filter((row) => selectedAlerts.includes(row.key));
  const selectedActionRows = actionRows.filter((row) => selectedActions.includes(row.key));

  function toggleSelection(id, setter) {
    setter((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  }

  function toggleAll(ids, selectedIds, setter) {
    setter(selectedIds.length === ids.length ? [] : ids);
  }

  function exportSelectedMeasures() {
    exportRowsAsCsv("historique-mesures-selectionnees.csv", ["date_mesure", "parcelle", "capteur", "type_mesure", "valeur", "unite"], selectedMeasureRows);
    logAudit({ page: "Historique", action: "Export CSV", details: `Export mesures - ${selectedMeasureRows.length} ligne(s)` });
  }

  function exportSelectedAlerts() {
    exportRowsAsCsv("historique-alertes-selectionnees.csv", ["date_creation", "parcelle", "type_alerte", "message", "niveau", "statut", "regle"], selectedAlertRows);
    logAudit({ page: "Historique", action: "Export CSV", details: `Export alertes - ${selectedAlertRows.length} ligne(s)` });
  }

  function exportSelectedActions() {
    exportRowsAsCsv("historique-actions-selectionnees.csv", ["date_action", "actionneur", "type_action", "source", "statut", "utilisateur"], selectedActionRows);
    logAudit({ page: "Historique", action: "Export CSV", details: `Export actions - ${selectedActionRows.length} ligne(s)` });
  }

  const measuresEmptyLabel = loadError || (isLoading ? "Chargement des mesures..." : "Aucune mesure recue");
  const alertsEmptyLabel = loadError || (isLoading ? "Chargement des alertes..." : "Aucune alerte recue");
  const actionsEmptyLabel = loadError || (isLoading ? "Chargement des actions..." : "Aucune commande recue");

  return (
    <section className="panel wide-panel history-page">
      <div className="history-header">
        <div>
          <h2>Historique</h2>
          <p>Mesures, alertes et commandes manuelles ou automatiques.</p>
        </div>
        <div className="history-tabs" role="tablist" aria-label="Types d'historique">
          {tabs.map((tab) => (
            <button key={tab} className={activeTab === tab ? "active" : ""} onClick={() => setActiveTab(tab)} type="button">
              {tab}
            </button>
          ))}
        </div>
      </div>

      {activeTab === "Mesures" && (
        <>
          <div className="table-toolbar">
            <div className="filters">
              <input type="date" value={dateFilter} onChange={(event) => { setDateFilter(event.target.value); setMeasurePage(1); }} />
              <select value={filter} onChange={(event) => { setFilter(event.target.value); setSelectedMeasures([]); setMeasurePage(1); }}>
                <option>Tous</option>
                <option>Humidite sol</option>
                <option>Temperature</option>
                <option>CO2</option>
                <option>Niveau eau</option>
                <option>Luminosite</option>
              </select>
            </div>
            <div className="toolbar-actions">
              <div className="selection-summary">
                <strong>{selectedMeasures.length}</strong>
                <span>mesure(s) selectionnee(s)</span>
              </div>
              <button className="primary-button small" onClick={exportSelectedMeasures} disabled={selectedMeasures.length === 0}>Export CSV</button>
            </div>
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th><input type="checkbox" checked={measureRows.length > 0 && selectedMeasures.length === measureRows.length} onChange={() => toggleAll(measureRows.map((row) => row.key), selectedMeasures, setSelectedMeasures)} /></th>
                  <th>Date mesure</th>
                  <th>Parcelle</th>
                  <th>Capteur</th>
                  <th>Type mesure</th>
                  <th>Valeur</th>
                  <th>Unite</th>
                </tr>
              </thead>
              <tbody>
                {measureMeta.paginatedRows.map((row) => (
                  <tr key={row.key} className={selectedMeasures.includes(row.key) ? "selected-row" : ""}>
                    <td><input type="checkbox" checked={selectedMeasures.includes(row.key)} onChange={() => toggleSelection(row.key, setSelectedMeasures)} /></td>
                    <td>{row.date_mesure}</td>
                    <td>{row.parcelle}</td>
                    <td>{row.capteur}</td>
                    <td><span className="status-badge neutral">{row.type_mesure}</span></td>
                    <td>{row.valeur}</td>
                    <td>{row.unite}</td>
                  </tr>
                ))}
                {measureRows.length === 0 && <EmptyRow colSpan={7} label={measuresEmptyLabel} />}
              </tbody>
            </table>
          </div>
          <Pagination label="Pagination des mesures" total={measureRows.length} page={measureMeta.safePage} pageCount={measureMeta.pageCount} startIndex={measureMeta.startIndex} endIndex={measureMeta.endIndex} onPageChange={setMeasurePage} />
        </>
      )}

      {activeTab === "Alertes" && (
        <>
          <div className="table-toolbar">
            <div className="selection-summary">
              <strong>{selectedAlerts.length}</strong>
              <span>alerte(s) selectionnee(s)</span>
            </div>
            <button className="primary-button small" onClick={exportSelectedAlerts} disabled={selectedAlerts.length === 0}>Export CSV</button>
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th><input type="checkbox" checked={alertRows.length > 0 && selectedAlerts.length === alertRows.length} onChange={() => toggleAll(alertRows.map((row) => row.key), selectedAlerts, setSelectedAlerts)} /></th>
                  <th>Date creation</th>
                  <th>Parcelle</th>
                  <th>Type alerte</th>
                  <th>Message</th>
                  <th>Niveau</th>
                  <th>Statut</th>
                  <th>Regle</th>
                </tr>
              </thead>
              <tbody>
                {alertMeta.paginatedRows.map((row) => (
                  <tr key={row.key} className={selectedAlerts.includes(row.key) ? "selected-row" : ""}>
                    <td><input type="checkbox" checked={selectedAlerts.includes(row.key)} onChange={() => toggleSelection(row.key, setSelectedAlerts)} /></td>
                    <td>{row.date_creation}</td>
                    <td>{row.parcelle}</td>
                    <td>{row.type_alerte}</td>
                    <td>{row.message}</td>
                    <td><span className={`status-badge ${tableBadgeClass(row.niveau)}`}>{row.niveau}</span></td>
                    <td><span className={`status-badge ${tableBadgeClass(row.statut)}`}>{row.statut}</span></td>
                    <td>{row.regle}</td>
                  </tr>
                ))}
                {alertRows.length === 0 && <EmptyRow colSpan={8} label={alertsEmptyLabel} />}
              </tbody>
            </table>
          </div>
          <Pagination label="Pagination des alertes" total={alertRows.length} page={alertMeta.safePage} pageCount={alertMeta.pageCount} startIndex={alertMeta.startIndex} endIndex={alertMeta.endIndex} onPageChange={setAlertPage} />
        </>
      )}

      {activeTab === "Actions" && (
        <>
          <div className="table-toolbar">
            <div className="selection-summary">
              <strong>{selectedActions.length}</strong>
              <span>action(s) selectionnee(s)</span>
            </div>
            <button className="primary-button small" onClick={exportSelectedActions} disabled={selectedActions.length === 0}>Export CSV</button>
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th><input type="checkbox" checked={actionRows.length > 0 && selectedActions.length === actionRows.length} onChange={() => toggleAll(actionRows.map((row) => row.key), selectedActions, setSelectedActions)} /></th>
                  <th>Date action</th>
                  <th>Actionneur</th>
                  <th>Type action</th>
                  <th>Source</th>
                  <th>Statut</th>
                  <th>Utilisateur</th>
                </tr>
              </thead>
              <tbody>
                {actionMeta.paginatedRows.map((row) => (
                  <tr key={row.key} className={selectedActions.includes(row.key) ? "selected-row" : ""}>
                    <td><input type="checkbox" checked={selectedActions.includes(row.key)} onChange={() => toggleSelection(row.key, setSelectedActions)} /></td>
                    <td>{row.date_action}</td>
                    <td>{row.actionneur}</td>
                    <td>{row.type_action}</td>
                    <td><span className="status-badge neutral">{row.source}</span></td>
                    <td><span className={`status-badge ${tableBadgeClass(row.statut)}`}>{row.statut}</span></td>
                    <td>{row.utilisateur}</td>
                  </tr>
                ))}
                {actionRows.length === 0 && <EmptyRow colSpan={7} label={actionsEmptyLabel} />}
              </tbody>
            </table>
          </div>
          <Pagination label="Pagination des actions" total={actionRows.length} page={actionMeta.safePage} pageCount={actionMeta.pageCount} startIndex={actionMeta.startIndex} endIndex={actionMeta.endIndex} onPageChange={setActionPage} />
        </>
      )}
    </section>
  );
}

